function check(form) { /*function to check userid & password*/
    /*the following code checkes whether the entered userid and password are matching*/
    if(form.userid.value == "skece" ) {
        window.open('index.html')/*opens the target page while Id & password matches*/
    }
    else {
        window.open('marko.html')/*displays error message*/
    }
}